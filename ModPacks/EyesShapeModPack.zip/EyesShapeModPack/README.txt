👁️ EyeShape Mod Maker

Love Android Workshop · Custom EyeShape Creation Guide

Create your own custom eyes shape for your androids! Whether you want to design realistic ones, unusual shapes, or completely different styles, this guide will help you get started.

=== 01 — Getting Started

Use the provided PSD template as a starting point for your design.

Design guidelines:

- All of your eyes shape assets must be exported following the export zone dimension of each pose, in png files.

- Try to keep the design consistent between each poses.

- If you create your own eyeWhite then contact me to add a new eyeMask fitting your design.

- Examples are included to help you.

=== 02 — Lineart Guidelines

To keep your mod visually consistent with the game's art style, I recommend using the following line thicknesses.

8 px — Outline

6 px — Detail

4 px — Small Detail <= Mainly used for eyes

These values are recommendations for maintaining visual consistency. Adjust them where necessary to suit your design.

=== 03 — Mod Preview

Create a preview image to showcase your mod. This image will help players identify your creation when browsing available mods.

512 × 512
Recommended resolution

=== 04 — Before Sharing Your Mod

A few final checks before publishing your creation:

- The eyes shape must be consistent between each poses.
- Your mod has been tested in-game before sharing.


To pack your mod and test it, you must use "LAW_Manifest_Helper.py".


Have fun creating your own unique eyes!