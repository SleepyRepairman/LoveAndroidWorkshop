👤 Body Mod Maker

Love Android Workshop · Custom Body Creation Guide

Create your own custom body for your androids! Whether you want to design realistic ones, unusual shapes, or completely different styles, this guide will help you get started.

=== 01 — Getting Started

Use the provided PSD template as a starting point for your design.

Design guidelines:

- All of your body assets must be exported as 4000x4000 png files.

- Try to keep the design consistent between each poses.

- You can use your own custom colors or the provided color palette to enable dynamic in-game color customization.

- Examples are included to help you.

=== 02 — Color Palette

The provided color palette allows your design to support dynamic colors in-game.

Light · Normal · Shade

Tip:

You don't have to use the dynamic color palette for every part of your design. You can also use your own colors for details that should remain unchanged.

=== 03 — Lineart Guidelines

To keep your mod visually consistent with the game's art style, I recommend using the following line thicknesses.

8 px — Outline

6 px — Detail

4 px — Small Detail

These values are recommendations for maintaining visual consistency. Adjust them where necessary to suit your design.

=== 04 — Mod Preview

Create a preview image to showcase your mod. This image will help players identify your creation when browsing available mods.

512 × 512
Recommended resolution

=== 05 — Before Sharing Your Mod

A few final checks before publishing your creation:

- The body must be consistent between each poses.
- Dynamic colors work as intended, if used.
- Your mod has been tested in-game before sharing.


To pack your mod and test it, you must use "LAW_Manifest_Helper.py".


Have fun creating your own unique heads!